---
title: A Sample Album
date: 2026-11-01
place: Anywhere, California
cover: photo-1.svg
summary: This is a sample album showing how a story and photos fit together. Replace it with your own.
---

Every album is a folder inside `albums/` with a `story.md` file and your photos. The text at the top of this file (between the dashes) sets the title, date, place, and cover photo.

The story below is just writing. Blank lines separate paragraphs, so write it the way you would tell the day to a friend.

![A single photo gets a caption like this](photo-1.svg)

## Giving it chapters

A line that starts with two hash marks becomes a heading, which is handy for breaking a long trip into parts, like morning and evening.

Put two photo lines directly next to each other, with no blank line between them, and they sit side by side.
![The first of a pair](photo-2.svg)
![The second of a pair](photo-3.svg)

When you are ready, delete the `sample-album` folder and add your own.
